# BadStars
Brawl Stars Rip Off

You are free to copy and/or edit this software however you want, but we wouldn't mind some credit ;)

You can download the latest release in the releases tab or on [itch.io](https://iddmeister.itch.io/bad-stars) (use the itch app to get automatic updates)
