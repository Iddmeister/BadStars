---
name: Feature request
about: Got an Idea, Tell us!
title: "[Feature Request]"
labels: enhancement
assignees: ''

---

**New Characters**
If you've got an idea for a new character then have a read of the wiki, there's a section on adding characters and you can make a pull request and hopefully have it added into the game. If you don't know how or are having difficulty making a character yourself then just give us a overview of the character in this feature request and we can add them for you.

**Other Ideas**
If you've got any ideas for the general game then just detail them here
